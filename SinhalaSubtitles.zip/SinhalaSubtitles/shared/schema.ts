import { z } from 'zod';
import { createInsertSchema } from 'drizzle-zod';

// Subtitle line interface
export interface SubtitleLine {
  index: number;
  startTime: string;
  endTime: string;
  originalText: string;
  translatedText?: string;
}

// Subtitle project schema
export const subtitleProjectSchema = z.object({
  id: z.string(),
  filename: z.string(),
  originalLanguage: z.string().default('en'),
  targetLanguage: z.string().default('si'), // Sinhala
  status: z.enum(['uploading', 'translating', 'completed', 'error']).default('uploading'),
  lines: z.array(z.object({
    index: z.number(),
    startTime: z.string(),
    endTime: z.string(),
    originalText: z.string(),
    translatedText: z.string().optional(),
  })),
  createdAt: z.date().default(() => new Date()),
  updatedAt: z.date().default(() => new Date()),
});

// Insert schema for creating new projects
export const insertSubtitleProjectSchema = subtitleProjectSchema.omit({ 
  id: true,
  createdAt: true,
  updatedAt: true 
});

// Types
export type SubtitleProject = z.infer<typeof subtitleProjectSchema>;
export type InsertSubtitleProject = z.infer<typeof insertSubtitleProjectSchema>;

// Individual line update schema
export const updateSubtitleLineSchema = z.object({
  projectId: z.string(),
  lineIndex: z.number(),
  translatedText: z.string(),
});

export type UpdateSubtitleLine = z.infer<typeof updateSubtitleLineSchema>;

// Supported subtitle formats
export const SUPPORTED_FORMATS = ['.srt', '.vtt', '.sub', '.ass', '.sbv', '.stl'] as const;
export const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB

// AI Translation request schema
export const translationRequestSchema = z.object({
  text: z.string(),
  sourceLanguage: z.string().default('en'),
  targetLanguage: z.string().default('si'),
  context: z.string().optional(),
});

export type TranslationRequest = z.infer<typeof translationRequestSchema>;