# Sinhala Subtitle Translator

## Overview
Professional AI-powered subtitle translation tool specifically designed for translating subtitles to Sinhala language. The application provides a modern, user-friendly interface for uploading subtitle files, translating them using advanced AI, and editing translations with real-time preview capabilities.

**Purpose**: Create the best AI-powered subtitle translator for Sinhala language with human-like translation quality
**Current State**: Fully functional application ready for deployment

## Recent Changes
- **2025-01-08**: Created complete full-stack application with AI translation service
- **2025-01-08**: Implemented file upload, parsing, and real-time editing features  
- **2025-01-08**: Added professional UI with next-level styling and user experience
- **2025-01-08**: Integrated download functionality for multiple subtitle formats

## User Preferences
Preferred communication style: Simple, everyday language
Translation focus: English to Sinhala (සිංහල) with human-like accuracy
UI Style: Professional, modern, next-level design

## System Architecture

### Frontend (React + TypeScript)
- **Framework**: React 19 with TypeScript
- **Styling**: Tailwind CSS with custom dark theme
- **Components**: Modern UI components with shadcn/ui design system
- **State Management**: TanStack Query for server state
- **File Upload**: React Dropzone with drag & drop support
- **Routing**: Wouter for client-side routing

### Backend (Node.js + Express)
- **Server**: Express.js with TypeScript
- **File Processing**: Multer for file uploads
- **Translation Engine**: Custom AI service for Sinhala translation
- **Subtitle Parsing**: Support for SRT, VTT, SUB, ASS, SBV, STL formats
- **Storage**: In-memory storage with full CRUD operations

### Key Features
1. **Multi-format Support**: SRT, VTT, SUB, ASS, SBV, STL subtitle formats
2. **AI Translation**: Advanced Sinhala translation with context awareness
3. **Real-time Editing**: Line-by-line editing with live preview
4. **Professional UI**: Modern, responsive design with dark theme
5. **Batch Operations**: Translate entire files or individual lines
6. **Download Options**: Export in SRT or VTT formats

### File Structure
```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # UI components
│   │   ├── lib/           # Utilities and API client
│   │   └── pages/         # Application pages
├── server/                # Backend Express server
│   ├── ai-translator.ts   # Sinhala translation service
│   ├── subtitle-parser.ts # Subtitle format parsers
│   ├── routes.ts          # API routes
│   └── storage.ts         # Data storage interface
├── shared/                # Shared types and schemas
└── start.js              # Development startup script
```

## External Dependencies
- React ecosystem (React, React DOM, React Query)
- Tailwind CSS for styling
- Express.js for backend API
- Multer for file upload handling
- Zod for data validation
- TypeScript for type safety
- Lucide React for icons

## Translation Engine
Custom AI translation service optimized for Sinhala language:
- Context-aware translations
- Cultural nuance preservation  
- Human-like natural language output
- Batch translation capabilities
- Real-time translation preview