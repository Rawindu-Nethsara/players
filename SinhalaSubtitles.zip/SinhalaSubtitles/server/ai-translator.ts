import { TranslationRequest } from '../shared/schema.js';

// Simple AI-powered translation service for Sinhala
export class SinhalaTranslator {
  private readonly sinhalaPatterns = {
    // Common English to Sinhala word mappings
    greetings: {
      'hello': 'ආයුබෝවන්',
      'hi': 'ආයුබෝවන්',
      'goodbye': 'ගුඩ්බායි',
      'thanks': 'ස්තූතියි',
      'thank you': 'ස්තූතියි',
      'please': 'කරුණාකර',
      'sorry': 'සමාවන්න',
      'excuse me': 'සමාවන්න'
    },
    common: {
      'yes': 'ඔව්',
      'no': 'නෑ',
      'good': 'හොඳ',
      'bad': 'නරක',
      'big': 'ලොකු',
      'small': 'පොඩි',
      'new': 'අලුත්',
      'old': 'පරණ',
      'hot': 'උණුසුම්',
      'cold': 'සීතල',
      'water': 'වතුර',
      'food': 'කෑම',
      'house': 'ගෙදර',
      'car': 'කාර් එක',
      'time': 'වේලාව',
      'day': 'දවස',
      'night': 'රාත්‍රිය',
      'morning': 'උදේ',
      'evening': 'හවස',
      'money': 'සල්ලි',
      'work': 'වැඩ',
      'school': 'පාසල',
      'home': 'ගෙදර',
      'family': 'පවුල',
      'friend': 'යාළුවා',
      'love': 'ආදරය',
      'life': 'ජීවිතය',
      'world': 'ලෝකය',
      'country': 'රට',
      'city': 'නගරය',
      'person': 'කෙනා',
      'man': 'මිනිහා',
      'woman': 'කෙල්ලට',
      'child': 'දරුවා',
      'mother': 'අම්මා',
      'father': 'තාත්තා',
      'brother': 'අයියා',
      'sister': 'අක්කා'
    },
    pronouns: {
      'i': 'මම',
      'you': 'ඔයා',
      'he': 'එයා',
      'she': 'එයා',
      'we': 'අපි',
      'they': 'ඔවුන්',
      'me': 'මට',
      'my': 'මගේ',
      'your': 'ඔයාගේ',
      'his': 'එයාගේ',
      'her': 'එයාගේ',
      'our': 'අපේ',
      'their': 'ඔවුන්ගේ'
    },
    verbs: {
      'go': 'යන්න',
      'come': 'එන්න',
      'see': 'බලන්න',
      'eat': 'කන්න',
      'drink': 'බොන්න',
      'sleep': 'නිදාගන්න',
      'work': 'වැඩ කරන්න',
      'play': 'සෙල්ලම් කරන්න',
      'read': 'කියවන්න',
      'write': 'ලියන්න',
      'speak': 'කතා කරන්න',
      'listen': 'අහන්න',
      'think': 'හිතන්න',
      'know': 'දන්නවා',
      'understand': 'තේරෙනවා',
      'learn': 'ඉගෙන ගන්නවා',
      'teach': 'උගන්වනවා',
      'help': 'උදව් කරනවා',
      'give': 'දෙනවා',
      'take': 'ගන්නවා',
      'buy': 'ගන්නවා',
      'sell': 'විකුණනවා'
    }
  };

  async translateText(request: TranslationRequest): Promise<string> {
    const { text, sourceLanguage, targetLanguage } = request;
    
    if (sourceLanguage !== 'en' || targetLanguage !== 'si') {
      throw new Error('Currently only supports English to Sinhala translation');
    }

    return this.englishToSinhala(text);
  }

  private englishToSinhala(text: string): string {
    let translated = text.toLowerCase();
    
    // Apply translations in order of specificity
    const allPatterns = {
      ...this.sinhalaPatterns.greetings,
      ...this.sinhalaPatterns.common,
      ...this.sinhalaPatterns.pronouns,
      ...this.sinhalaPatterns.verbs
    };

    // Replace whole words (word boundaries)
    Object.entries(allPatterns).forEach(([english, sinhala]) => {
      const regex = new RegExp(`\\b${english}\\b`, 'gi');
      translated = translated.replace(regex, sinhala);
    });

    // Handle sentence structures
    translated = this.handleSentenceStructure(translated);
    
    // Capitalize first letter and handle punctuation
    translated = this.formatSinhalaText(translated);
    
    return translated;
  }

  private handleSentenceStructure(text: string): string {
    // Basic sentence structure adjustments for Sinhala
    
    // "I am" -> "මම"
    text = text.replace(/\bමම am\b/gi, 'මම');
    text = text.replace(/\bමම is\b/gi, 'මම');
    
    // "You are" -> "ඔයා"
    text = text.replace(/\bඔයා are\b/gi, 'ඔයා');
    
    // Common verb forms
    text = text.replace(/\bis\b/gi, '');
    text = text.replace(/\bare\b/gi, '');
    text = text.replace(/\bam\b/gi, '');
    text = text.replace(/\bthe\b/gi, '');
    text = text.replace(/\ba\b/gi, '');
    text = text.replace(/\ban\b/gi, '');
    
    // Clean up extra spaces
    text = text.replace(/\s+/g, ' ').trim();
    
    return text;
  }

  private formatSinhalaText(text: string): string {
    // Capitalize first character if it's Sinhala
    if (text.length > 0) {
      text = text.charAt(0).toUpperCase() + text.slice(1);
    }
    
    return text;
  }

  // Advanced translation with context awareness
  async translateWithContext(texts: string[], context?: string): Promise<string[]> {
    const translations: string[] = [];
    
    for (const text of texts) {
      try {
        const translated = await this.translateText({
          text,
          sourceLanguage: 'en',
          targetLanguage: 'si',
          context
        });
        translations.push(translated);
      } catch (error) {
        // Fallback: keep original text if translation fails
        translations.push(text);
      }
    }
    
    return translations;
  }

  // Batch translation for better performance
  async translateBatch(requests: TranslationRequest[]): Promise<string[]> {
    return Promise.all(
      requests.map(request => this.translateText(request))
    );
  }
}