import { SubtitleLine } from '../shared/schema.js';

export class SubtitleParser {
  static parseFile(content: string, filename: string): SubtitleLine[] {
    const extension = filename.toLowerCase().substring(filename.lastIndexOf('.'));
    
    switch (extension) {
      case '.srt':
        return this.parseSRT(content);
      case '.vtt':
        return this.parseVTT(content);
      case '.sub':
        return this.parseSUB(content);
      case '.ass':
        return this.parseASS(content);
      case '.sbv':
        return this.parseSBV(content);
      case '.stl':
        return this.parseSTL(content);
      default:
        throw new Error(`Unsupported file format: ${extension}`);
    }
  }

  private static parseSRT(content: string): SubtitleLine[] {
    const lines: SubtitleLine[] = [];
    const blocks = content.trim().split(/\n\s*\n/);

    for (const block of blocks) {
      const blockLines = block.trim().split('\n');
      if (blockLines.length < 3) continue;

      const index = parseInt(blockLines[0].trim());
      const timeMatch = blockLines[1].match(/(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})/);
      
      if (timeMatch) {
        const startTime = timeMatch[1];
        const endTime = timeMatch[2];
        const originalText = blockLines.slice(2).join('\n').trim();

        lines.push({
          index,
          startTime,
          endTime,
          originalText
        });
      }
    }

    return lines;
  }

  private static parseVTT(content: string): SubtitleLine[] {
    const lines: SubtitleLine[] = [];
    const blocks = content.replace(/^WEBVTT\s*\n/, '').trim().split(/\n\s*\n/);
    let index = 1;

    for (const block of blocks) {
      const blockLines = block.trim().split('\n');
      if (blockLines.length < 2) continue;

      const timeMatch = blockLines[0].match(/(\d{2}:\d{2}:\d{2}\.\d{3}) --> (\d{2}:\d{2}:\d{2}\.\d{3})/);
      
      if (timeMatch) {
        const startTime = timeMatch[1].replace('.', ',');
        const endTime = timeMatch[2].replace('.', ',');
        const originalText = blockLines.slice(1).join('\n').trim();

        lines.push({
          index: index++,
          startTime,
          endTime,
          originalText
        });
      }
    }

    return lines;
  }

  private static parseSUB(content: string): SubtitleLine[] {
    const lines: SubtitleLine[] = [];
    const blocks = content.trim().split('\n');
    
    for (const block of blocks) {
      const match = block.match(/\{(\d+)\}\{(\d+)\}(.+)/);
      if (match) {
        const startFrame = parseInt(match[1]);
        const endFrame = parseInt(match[2]);
        const originalText = match[3].trim();

        // Convert frames to time (assuming 25 fps)
        const startTime = this.framesToTime(startFrame, 25);
        const endTime = this.framesToTime(endFrame, 25);

        lines.push({
          index: lines.length + 1,
          startTime,
          endTime,
          originalText
        });
      }
    }

    return lines;
  }

  private static parseASS(content: string): SubtitleLine[] {
    const lines: SubtitleLine[] = [];
    const dialogueLines = content.split('\n').filter(line => line.startsWith('Dialogue:'));
    
    for (const line of dialogueLines) {
      const parts = line.split(',');
      if (parts.length >= 10) {
        const startTime = this.assTimeToSrt(parts[1]);
        const endTime = this.assTimeToSrt(parts[2]);
        const originalText = parts.slice(9).join(',').replace(/\{[^}]*\}/g, '').trim();

        lines.push({
          index: lines.length + 1,
          startTime,
          endTime,
          originalText
        });
      }
    }

    return lines;
  }

  private static parseSBV(content: string): SubtitleLine[] {
    const lines: SubtitleLine[] = [];
    const blocks = content.trim().split(/\n\s*\n/);
    
    for (const block of blocks) {
      const blockLines = block.trim().split('\n');
      if (blockLines.length < 2) continue;

      const timeMatch = blockLines[0].match(/(\d+:\d+:\d+\.\d+),(\d+:\d+:\d+\.\d+)/);
      
      if (timeMatch) {
        const startTime = timeMatch[1].replace('.', ',');
        const endTime = timeMatch[2].replace('.', ',');
        const originalText = blockLines.slice(1).join('\n').trim();

        lines.push({
          index: lines.length + 1,
          startTime,
          endTime,
          originalText
        });
      }
    }

    return lines;
  }

  private static parseSTL(content: string): SubtitleLine[] {
    // STL is a binary format, but we'll handle simple text-based STL
    const lines: SubtitleLine[] = [];
    const blocks = content.trim().split(/\n\s*\n/);
    
    for (const block of blocks) {
      const blockLines = block.trim().split('\n');
      if (blockLines.length < 2) continue;

      // Simple STL format: timecode text
      const timeMatch = blockLines[0].match(/(\d{2}:\d{2}:\d{2}:\d{2}) (\d{2}:\d{2}:\d{2}:\d{2})/);
      
      if (timeMatch) {
        const startTime = timeMatch[1].replace(':', ',');
        const endTime = timeMatch[2].replace(':', ',');
        const originalText = blockLines.slice(1).join('\n').trim();

        lines.push({
          index: lines.length + 1,
          startTime,
          endTime,
          originalText
        });
      }
    }

    return lines;
  }

  private static framesToTime(frames: number, fps: number): string {
    const totalSeconds = frames / fps;
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);
    const milliseconds = Math.floor((totalSeconds % 1) * 1000);

    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')},${milliseconds.toString().padStart(3, '0')}`;
  }

  private static assTimeToSrt(assTime: string): string {
    // Convert ASS time (H:MM:SS.ss) to SRT time (HH:MM:SS,mmm)
    const parts = assTime.split(':');
    const hours = parts[0].padStart(2, '0');
    const minutes = parts[1];
    const secondsParts = parts[2].split('.');
    const seconds = secondsParts[0];
    const centiseconds = secondsParts[1] || '00';
    const milliseconds = (parseInt(centiseconds) * 10).toString().padStart(3, '0');

    return `${hours}:${minutes}:${seconds},${milliseconds}`;
  }

  static generateSRT(lines: SubtitleLine[]): string {
    return lines
      .map(line => {
        const text = line.translatedText || line.originalText;
        return `${line.index}\n${line.startTime} --> ${line.endTime}\n${text}\n`;
      })
      .join('\n');
  }

  static generateVTT(lines: SubtitleLine[]): string {
    const content = lines
      .map(line => {
        const text = line.translatedText || line.originalText;
        const startTime = line.startTime.replace(',', '.');
        const endTime = line.endTime.replace(',', '.');
        return `${startTime} --> ${endTime}\n${text}\n`;
      })
      .join('\n');

    return `WEBVTT\n\n${content}`;
  }
}