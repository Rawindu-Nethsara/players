import express, { Request, Response } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { IStorage } from './storage.js';
import { SinhalaTranslator } from './ai-translator.js';
import { SubtitleParser } from './subtitle-parser.js';
import { 
  insertSubtitleProjectSchema,
  updateSubtitleLineSchema,
  SUPPORTED_FORMATS,
  MAX_FILE_SIZE,
  SubtitleProject
} from '../shared/schema.js';

const router = express.Router();

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: MAX_FILE_SIZE,
  },
  fileFilter: (req, file, cb) => {
    const ext = file.originalname.toLowerCase().substring(file.originalname.lastIndexOf('.'));
    if (SUPPORTED_FORMATS.includes(ext as any)) {
      cb(null, true);
    } else {
      cb(new Error(`Unsupported file format. Supported formats: ${SUPPORTED_FORMATS.join(', ')}`));
    }
  }
});

export function createRoutes(storage: IStorage) {
  const translator = new SinhalaTranslator();

  // Get all projects
  router.get('/api/projects', async (req: Request, res: Response) => {
    try {
      const projects = await storage.getAllProjects();
      res.json(projects);
    } catch (error) {
      console.error('Error fetching projects:', error);
      res.status(500).json({ error: 'Failed to fetch projects' });
    }
  });

  // Get single project
  router.get('/api/projects/:id', async (req: Request, res: Response) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      res.json(project);
    } catch (error) {
      console.error('Error fetching project:', error);
      res.status(500).json({ error: 'Failed to fetch project' });
    }
  });

  // Upload and parse subtitle file
  router.post('/api/upload', upload.single('subtitle'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }

      const content = req.file.buffer.toString('utf-8');
      const lines = SubtitleParser.parseFile(content, req.file.originalname);

      if (lines.length === 0) {
        return res.status(400).json({ error: 'No subtitle lines found in file' });
      }

      const projectData = insertSubtitleProjectSchema.parse({
        filename: req.file.originalname,
        originalLanguage: 'en',
        targetLanguage: 'si',
        status: 'uploading' as const,
        lines: lines
      });

      const project = await storage.createProject(projectData);
      res.json(project);
    } catch (error) {
      console.error('Error uploading file:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid file format', details: error.issues });
      }
      res.status(500).json({ error: 'Failed to process subtitle file' });
    }
  });

  // Translate entire project
  router.post('/api/projects/:id/translate', async (req: Request, res: Response) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      // Update status to translating
      await storage.updateProject(req.params.id, { status: 'translating' });

      // Extract all text for batch translation
      const textsToTranslate = project.lines.map(line => line.originalText);
      
      try {
        // Translate all texts
        const translatedTexts = await translator.translateWithContext(
          textsToTranslate,
          `Subtitle translation for ${project.filename}`
        );

        // Update all lines with translations
        const updatedLines = project.lines.map((line, index) => ({
          ...line,
          translatedText: translatedTexts[index]
        }));

        // Update project with translated lines
        const updatedProject = await storage.updateProject(req.params.id, {
          lines: updatedLines,
          status: 'completed'
        });

        res.json(updatedProject);
      } catch (translationError) {
        console.error('Translation error:', translationError);
        await storage.updateProject(req.params.id, { status: 'error' });
        res.status(500).json({ error: 'Translation failed' });
      }
    } catch (error) {
      console.error('Error translating project:', error);
      res.status(500).json({ error: 'Failed to translate project' });
    }
  });

  // Update single line
  router.patch('/api/projects/:id/lines', async (req: Request, res: Response) => {
    try {
      const updateData = updateSubtitleLineSchema.parse({
        projectId: req.params.id,
        ...req.body
      });

      const success = await storage.updateLine(updateData);
      if (!success) {
        return res.status(404).json({ error: 'Project or line not found' });
      }

      const updatedProject = await storage.getProject(req.params.id);
      res.json(updatedProject);
    } catch (error) {
      console.error('Error updating line:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid data', details: error.issues });
      }
      res.status(500).json({ error: 'Failed to update line' });
    }
  });

  // Update multiple lines
  router.patch('/api/projects/:id/lines/batch', async (req: Request, res: Response) => {
    try {
      const { lines } = req.body;
      if (!Array.isArray(lines)) {
        return res.status(400).json({ error: 'Lines must be an array' });
      }

      const success = await storage.updateMultipleLines(req.params.id, lines);
      if (!success) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const updatedProject = await storage.getProject(req.params.id);
      res.json(updatedProject);
    } catch (error) {
      console.error('Error updating lines:', error);
      res.status(500).json({ error: 'Failed to update lines' });
    }
  });

  // Download translated subtitle file
  router.get('/api/projects/:id/download', async (req: Request, res: Response) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const format = (req.query.format as string) || 'srt';
      let content: string;
      let mimeType: string;
      let extension: string;

      switch (format.toLowerCase()) {
        case 'vtt':
          content = SubtitleParser.generateVTT(project.lines);
          mimeType = 'text/vtt';
          extension = 'vtt';
          break;
        case 'srt':
        default:
          content = SubtitleParser.generateSRT(project.lines);
          mimeType = 'application/x-subrip';
          extension = 'srt';
          break;
      }

      const filename = project.filename.replace(/\.[^/.]+$/, '') + `_sinhala.${extension}`;

      res.setHeader('Content-Type', mimeType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(content);
    } catch (error) {
      console.error('Error downloading file:', error);
      res.status(500).json({ error: 'Failed to generate download' });
    }
  });

  // Delete project
  router.delete('/api/projects/:id', async (req: Request, res: Response) => {
    try {
      const success = await storage.deleteProject(req.params.id);
      if (!success) {
        return res.status(404).json({ error: 'Project not found' });
      }
      res.json({ message: 'Project deleted successfully' });
    } catch (error) {
      console.error('Error deleting project:', error);
      res.status(500).json({ error: 'Failed to delete project' });
    }
  });

  // Translate single text (for real-time editing)
  router.post('/api/translate', async (req: Request, res: Response) => {
    try {
      const { text, sourceLanguage = 'en', targetLanguage = 'si' } = req.body;
      
      if (!text) {
        return res.status(400).json({ error: 'Text is required' });
      }

      const translatedText = await translator.translateText({
        text,
        sourceLanguage,
        targetLanguage
      });

      res.json({ translatedText });
    } catch (error) {
      console.error('Error translating text:', error);
      res.status(500).json({ error: 'Translation failed' });
    }
  });

  return router;
}