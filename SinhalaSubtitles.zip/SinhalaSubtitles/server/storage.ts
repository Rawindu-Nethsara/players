import { SubtitleProject, InsertSubtitleProject, UpdateSubtitleLine } from '../shared/schema.js';

export interface IStorage {
  // Project management
  createProject(project: InsertSubtitleProject): Promise<SubtitleProject>;
  getProject(id: string): Promise<SubtitleProject | null>;
  getAllProjects(): Promise<SubtitleProject[]>;
  updateProject(id: string, updates: Partial<SubtitleProject>): Promise<SubtitleProject | null>;
  deleteProject(id: string): Promise<boolean>;
  
  // Line management
  updateLine(update: UpdateSubtitleLine): Promise<boolean>;
  updateMultipleLines(projectId: string, lines: { index: number; translatedText: string }[]): Promise<boolean>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private projects: Map<string, SubtitleProject> = new Map();

  async createProject(project: InsertSubtitleProject): Promise<SubtitleProject> {
    const id = Date.now().toString(36) + Math.random().toString(36).substr(2);
    const newProject: SubtitleProject = {
      ...project,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    this.projects.set(id, newProject);
    return newProject;
  }

  async getProject(id: string): Promise<SubtitleProject | null> {
    return this.projects.get(id) || null;
  }

  async getAllProjects(): Promise<SubtitleProject[]> {
    return Array.from(this.projects.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async updateProject(id: string, updates: Partial<SubtitleProject>): Promise<SubtitleProject | null> {
    const existing = this.projects.get(id);
    if (!existing) return null;

    const updated = {
      ...existing,
      ...updates,
      updatedAt: new Date(),
    };

    this.projects.set(id, updated);
    return updated;
  }

  async deleteProject(id: string): Promise<boolean> {
    return this.projects.delete(id);
  }

  async updateLine(update: UpdateSubtitleLine): Promise<boolean> {
    const project = this.projects.get(update.projectId);
    if (!project) return false;

    const lineIndex = project.lines.findIndex(line => line.index === update.lineIndex);
    if (lineIndex === -1) return false;

    project.lines[lineIndex].translatedText = update.translatedText;
    project.updatedAt = new Date();
    
    return true;
  }

  async updateMultipleLines(
    projectId: string, 
    lines: { index: number; translatedText: string }[]
  ): Promise<boolean> {
    const project = this.projects.get(projectId);
    if (!project) return false;

    lines.forEach(({ index, translatedText }) => {
      const lineIndex = project.lines.findIndex(line => line.index === index);
      if (lineIndex !== -1) {
        project.lines[lineIndex].translatedText = translatedText;
      }
    });

    project.updatedAt = new Date();
    return true;
  }
}