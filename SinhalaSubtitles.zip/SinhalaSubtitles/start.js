// Start both client and server for development
import { spawn } from 'child_process';

// Start server
const server = spawn('tsx', ['server/index.ts'], {
  stdio: 'inherit',
  cwd: process.cwd()
});

// Start client (Vite dev server)
const client = spawn('npx', ['vite', '--host', '0.0.0.0', '--port', '5000'], {
  stdio: 'inherit',
  cwd: 'client'
});

// Handle cleanup
process.on('SIGINT', () => {
  server.kill();
  client.kill();
  process.exit();
});

console.log('🚀 Starting Sinhala Subtitle Translator...');
console.log('📱 Frontend: http://localhost:5000');
console.log('⚡ Backend: http://localhost:5000/api');
console.log('🛑 Press Ctrl+C to stop');