import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Play, 
  Pause, 
  Download, 
  Edit3, 
  Save, 
  X, 
  Languages,
  RefreshCw,
  Zap
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Progress } from './ui/progress';
import { apiRequest } from '../lib/queryClient';
import { formatTime } from '../lib/utils';

interface SubtitleEditorProps {
  projectId: string;
  onBack: () => void;
}

interface SubtitleLine {
  index: number;
  startTime: string;
  endTime: string;
  originalText: string;
  translatedText?: string;
}

interface SubtitleProject {
  id: string;
  filename: string;
  originalLanguage: string;
  targetLanguage: string;
  status: 'uploading' | 'translating' | 'completed' | 'error';
  lines: SubtitleLine[];
}

export function SubtitleEditor({ projectId, onBack }: SubtitleEditorProps) {
  const [editingLine, setEditingLine] = useState<number | null>(null);
  const [editText, setEditText] = useState('');
  const [playingLine, setPlayingLine] = useState<number | null>(null);
  const queryClient = useQueryClient();

  const { data: project, isLoading } = useQuery<SubtitleProject>({
    queryKey: ['/api/projects', projectId],
    queryFn: () => apiRequest(`/api/projects/${projectId}`),
  });

  const translateMutation = useMutation({
    mutationFn: () => apiRequest(`/api/projects/${projectId}/translate`, {
      method: 'POST',
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId] });
    },
  });

  const updateLineMutation = useMutation({
    mutationFn: ({ lineIndex, translatedText }: { lineIndex: number; translatedText: string }) =>
      apiRequest(`/api/projects/${projectId}/lines`, {
        method: 'PATCH',
        body: JSON.stringify({ lineIndex, translatedText }),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId] });
      setEditingLine(null);
    },
  });

  const startEdit = (lineIndex: number, currentText: string) => {
    setEditingLine(lineIndex);
    setEditText(currentText);
  };

  const saveEdit = () => {
    if (editingLine !== null) {
      updateLineMutation.mutate({
        lineIndex: editingLine,
        translatedText: editText,
      });
    }
  };

  const cancelEdit = () => {
    setEditingLine(null);
    setEditText('');
  };

  const handleDownload = (format: 'srt' | 'vtt' = 'srt') => {
    const url = `/api/projects/${projectId}/download?format=${format}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = '';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const togglePlayLine = (lineIndex: number) => {
    setPlayingLine(playingLine === lineIndex ? null : lineIndex);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-green-500';
      case 'translating':
        return 'text-blue-500';
      case 'error':
        return 'text-red-500';
      default:
        return 'text-yellow-500';
    }
  };

  const getTranslationProgress = () => {
    if (!project?.lines) return 0;
    const translated = project.lines.filter(line => line.translatedText).length;
    return (translated / project.lines.length) * 100;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Loading project...</p>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-muted-foreground">Project not found</p>
        <Button onClick={onBack} className="mt-4" data-testid="button-back">
          Go Back
        </Button>
      </div>
    );
  }

  const translationProgress = getTranslationProgress();

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="gradient-bg text-white">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white mb-2" data-testid="text-project-title">
                {project.filename}
              </CardTitle>
              <div className="flex items-center space-x-4 text-sm text-white/80">
                <span className="flex items-center space-x-1">
                  <Languages className="w-4 h-4" />
                  <span>English → Sinhala</span>
                </span>
                <span className={`flex items-center space-x-1 ${getStatusColor(project.status)}`}>
                  <div className="w-2 h-2 rounded-full bg-current"></div>
                  <span className="capitalize">{project.status}</span>
                </span>
                <span data-testid="text-line-count">
                  {project.lines.length} lines
                </span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="secondary"
                onClick={onBack}
                data-testid="button-back"
              >
                <X className="w-4 h-4 mr-2" />
                Close
              </Button>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-sm text-white/80">
              <span>Translation Progress</span>
              <span>{Math.round(translationProgress)}%</span>
            </div>
            <Progress 
              value={translationProgress} 
              className="bg-white/20" 
              data-testid="translation-progress"
            />
          </div>
        </CardHeader>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-2">
          <Button
            onClick={() => translateMutation.mutate()}
            disabled={translateMutation.isPending || project.status === 'translating'}
            variant="gradient"
            data-testid="button-translate"
          >
            {translateMutation.isPending ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Translating...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                {translationProgress > 0 ? 'Re-translate All' : 'Translate All'}
              </>
            )}
          </Button>
          
          {translationProgress > 0 && (
            <div className="text-sm text-muted-foreground">
              {project.lines.filter(line => line.translatedText).length} of {project.lines.length} translated
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            onClick={() => handleDownload('srt')}
            disabled={translationProgress === 0}
            data-testid="button-download-srt"
          >
            <Download className="w-4 h-4 mr-2" />
            Download SRT
          </Button>
          <Button
            variant="outline"
            onClick={() => handleDownload('vtt')}
            disabled={translationProgress === 0}
            data-testid="button-download-vtt"
          >
            <Download className="w-4 h-4 mr-2" />
            Download VTT
          </Button>
        </div>
      </div>

      {/* Subtitle Lines */}
      <div className="space-y-4">
        {project.lines.map((line) => (
          <Card 
            key={line.index} 
            className={`transition-all ${playingLine === line.index ? 'ring-2 ring-primary' : ''}`}
          >
            <CardContent className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Original Text */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-sm text-muted-foreground">
                      Original (English)
                    </h4>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-muted-foreground" data-testid={`text-time-${line.index}`}>
                        {formatTime(line.startTime)} - {formatTime(line.endTime)}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => togglePlayLine(line.index)}
                        className="h-6 w-6"
                        data-testid={`button-play-${line.index}`}
                      >
                        {playingLine === line.index ? (
                          <Pause className="w-3 h-3" />
                        ) : (
                          <Play className="w-3 h-3" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-md" data-testid={`text-original-${line.index}`}>
                    <p className="text-sm">{line.originalText}</p>
                  </div>
                </div>

                {/* Translated Text */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-sm text-muted-foreground">
                      Sinhala Translation
                    </h4>
                    {line.translatedText && editingLine !== line.index && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => startEdit(line.index, line.translatedText || '')}
                        data-testid={`button-edit-${line.index}`}
                      >
                        <Edit3 className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                    )}
                  </div>
                  
                  {editingLine === line.index ? (
                    <div className="space-y-2">
                      <Textarea
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        className="min-h-[80px]"
                        placeholder="Enter Sinhala translation..."
                        data-testid={`textarea-edit-${line.index}`}
                      />
                      <div className="flex items-center space-x-2">
                        <Button
                          size="sm"
                          onClick={saveEdit}
                          disabled={updateLineMutation.isPending}
                          data-testid={`button-save-${line.index}`}
                        >
                          <Save className="w-3 h-3 mr-1" />
                          Save
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={cancelEdit}
                          data-testid={`button-cancel-${line.index}`}
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div 
                      className={`p-3 rounded-md min-h-[60px] flex items-center ${
                        line.translatedText 
                          ? 'bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800' 
                          : 'bg-muted/30 border-2 border-dashed border-muted-foreground/30'
                      }`}
                      data-testid={`text-translated-${line.index}`}
                    >
                      {line.translatedText ? (
                        <p className="text-sm">{line.translatedText}</p>
                      ) : (
                        <p className="text-sm text-muted-foreground italic">
                          Not translated yet - click "Translate All" or edit manually
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}