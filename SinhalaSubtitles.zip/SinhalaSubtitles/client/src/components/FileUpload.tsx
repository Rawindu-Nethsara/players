import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText, X } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { formatFileSize, isValidSubtitleFormat } from '../lib/utils';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';

interface FileUploadProps {
  onProjectCreated: (projectId: string) => void;
}

export function FileUpload({ onProjectCreated }: FileUploadProps) {
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('subtitle', file);
      
      return fetch('/api/upload', {
        method: 'POST',
        body: formData,
      }).then(async (response) => {
        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.error || 'Upload failed');
        }
        return response.json();
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      onProjectCreated(data.id);
      setSelectedFile(null);
      setUploadProgress(0);
    },
    onError: (error) => {
      console.error('Upload failed:', error);
      setUploadProgress(0);
    }
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file && isValidSubtitleFormat(file.name)) {
      setSelectedFile(file);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/*': ['.srt', '.vtt', '.sub', '.ass', '.sbv', '.stl'],
    },
    multiple: false,
    maxSize: 100 * 1024 * 1024, // 100MB
  });

  const handleUpload = () => {
    if (selectedFile) {
      setUploadProgress(10);
      uploadMutation.mutate(selectedFile);
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
    setUploadProgress(0);
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4">
      {/* Upload Area */}
      <Card className="border-2 border-dashed border-border hover:border-primary/50 transition-colors">
        <CardContent className="p-8">
          <div
            {...getRootProps()}
            className={`cursor-pointer text-center space-y-4 ${
              isDragActive ? 'opacity-80' : ''
            }`}
            data-testid="file-upload-area"
          >
            <input {...getInputProps()} data-testid="file-input" />
            
            <div className="mx-auto w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
              <Upload className="w-12 h-12 text-primary" />
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2">
                {isDragActive ? 'Drop your subtitle file here' : 'Upload Subtitle File'}
              </h3>
              <p className="text-muted-foreground mb-4">
                Drag & drop or click to select your subtitle file
              </p>
              <p className="text-sm text-muted-foreground">
                Supports: SRT, VTT, SUB, ASS, SBV, STL • Max 100MB
              </p>
            </div>
            
            {!selectedFile && (
              <Button variant="gradient" size="lg" data-testid="button-browse">
                Browse Files
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Selected File */}
      {selectedFile && (
        <Card className="animate-fade-in">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <FileText className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="font-medium" data-testid="text-filename">
                    {selectedFile.name}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {formatFileSize(selectedFile.size)}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                {!uploadMutation.isPending && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={removeFile}
                    data-testid="button-remove-file"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
                
                <Button
                  variant="gradient"
                  onClick={handleUpload}
                  disabled={uploadMutation.isPending}
                  data-testid="button-upload"
                >
                  {uploadMutation.isPending ? 'Uploading...' : 'Upload & Process'}
                </Button>
              </div>
            </div>
            
            {uploadMutation.isPending && (
              <div className="mt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Processing file...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} data-testid="upload-progress" />
              </div>
            )}
            
            {uploadMutation.error && (
              <div className="mt-4 p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                <p className="text-sm text-destructive">
                  {uploadMutation.error.message}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Supported Formats Info */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-center">
        {[
          { format: 'SRT', desc: 'SubRip' },
          { format: 'VTT', desc: 'WebVTT' },
          { format: 'SUB', desc: 'MicroDVD' },
          { format: 'ASS', desc: 'Advanced SSA' },
          { format: 'SBV', desc: 'YouTube' },
          { format: 'STL', desc: 'Spruce STL' }
        ].map((item) => (
          <div key={item.format} className="p-3 rounded-lg bg-muted/30">
            <div className="font-medium text-sm">{item.format}</div>
            <div className="text-xs text-muted-foreground">{item.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}