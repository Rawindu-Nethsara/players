import React, { useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from './lib/queryClient';
import { FileUpload } from './components/FileUpload';
import { SubtitleEditor } from './components/SubtitleEditor';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Languages, Sparkles, Globe } from 'lucide-react';

function App() {
  const [currentProjectId, setCurrentProjectId] = useState<string | null>(null);

  const handleProjectCreated = (projectId: string) => {
    setCurrentProjectId(projectId);
  };

  const handleBackToUpload = () => {
    setCurrentProjectId(null);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
        {/* Header */}
        <div className="gradient-bg text-white py-12 px-4">
          <div className="max-w-6xl mx-auto text-center">
            <div className="flex items-center justify-center mb-6">
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
                <Languages className="w-8 h-8" />
              </div>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-4">
              Sinhala Subtitle Translator
            </h1>
            <p className="text-xl md:text-2xl text-white/80 mb-6 max-w-3xl mx-auto">
              Professional AI-powered subtitle translation tool with human-like accuracy for Sinhala language
            </p>
            <div className="flex items-center justify-center space-x-8 text-sm">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4" />
                <span>AI-Powered Translation</span>
              </div>
              <div className="flex items-center space-x-2">
                <Globe className="w-4 h-4" />
                <span>6 Subtitle Formats</span>
              </div>
              <div className="flex items-center space-x-2">
                <Languages className="w-4 h-4" />
                <span>Real-time Editing</span>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-6xl mx-auto px-4 py-12">
          {!currentProjectId ? (
            <div className="space-y-12">
              {/* Upload Section */}
              <div>
                <div className="text-center mb-8">
                  <h2 className="text-2xl font-semibold mb-4">
                    Upload Your Subtitle File
                  </h2>
                  <p className="text-muted-foreground max-w-2xl mx-auto">
                    Choose your subtitle file to begin the translation process. Our advanced AI will 
                    translate it to natural-sounding Sinhala with professional accuracy.
                  </p>
                </div>
                <FileUpload onProjectCreated={handleProjectCreated} />
              </div>

              {/* Features */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="text-center">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                      <Sparkles className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle className="text-lg">AI-Powered Translation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Advanced AI model specifically trained for natural Sinhala translations 
                      that maintain context and cultural nuances.
                    </p>
                  </CardContent>
                </Card>

                <Card className="text-center">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                      <Languages className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle className="text-lg">Real-time Editing</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Edit translations line by line with live preview. Perfect your 
                      subtitles with professional editing tools.
                    </p>
                  </CardContent>
                </Card>

                <Card className="text-center">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                      <Globe className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle className="text-lg">Multiple Formats</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Support for SRT, VTT, SUB, ASS, SBV, and STL formats. 
                      Download in your preferred format.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : (
            <SubtitleEditor 
              projectId={currentProjectId} 
              onBack={handleBackToUpload} 
            />
          )}
        </div>

        {/* Footer */}
        <footer className="bg-muted/30 py-8 px-4 mt-20">
          <div className="max-w-6xl mx-auto text-center">
            <p className="text-sm text-muted-foreground">
              Professional Sinhala Subtitle Translator • Built with Modern AI Technology
            </p>
          </div>
        </footer>
      </div>
    </QueryClientProvider>
  );
}

export default App;